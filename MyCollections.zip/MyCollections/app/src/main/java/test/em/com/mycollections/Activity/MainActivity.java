package test.em.com.mycollections.Activity;

/**
 * Created by Sasinun on 5/28/16.
 */
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

import android.content.Context;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.view.GestureDetector;
import android.view.MotionEvent;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import my500pic.ConstantUtils;
import my500pic.MyApplication;
import test.em.com.mycollections.CollectionAdapter;
import test.em.com.mycollections.DividerItemDecoration;
import test.em.com.mycollections.R;
import test.em.com.mycollections.ShowCollectionListActivity;

public class MainActivity extends AppCompatActivity {

    private List<String> dataList = new ArrayList<>();
    private RecyclerView recyclerView;
    private CollectionAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        dataList = getCategoryList();
        mAdapter = new CollectionAdapter(dataList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(mAdapter);

        recyclerView.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(), recyclerView, new ClickListener() {
            @Override
            public void onClick(View view, int position) {
                String data = dataList.get(position);
                //Toast.makeText(getApplicationContext(), data + " is selected!", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(MainActivity.this, ShowCollectionListActivity.class);
                i.putExtra("POSITION",position);
                startActivity(i);
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

        prepareCollectionData();
    }

    private void prepareCollectionData() {
        //dataList = Arrays.asList(ConstantUtils.CATEGORY_ARRAY);

        mAdapter.notifyDataSetChanged();
    }
    private ArrayList<String> getCategoryList(){
        ArrayList<String> list = new ArrayList<>();
        HashMap<Integer,Integer> map = MyApplication.photoPosGlobal;
        for(int key : map.keySet()){
            list.add(ConstantUtils.CATEGORY_ARRAY[key]);
        }
        return list;
    }
    public interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private MainActivity.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final MainActivity.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildPosition(child));
                    }
                }
            });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }
}


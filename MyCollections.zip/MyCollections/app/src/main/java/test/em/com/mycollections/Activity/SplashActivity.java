package test.em.com.mycollections.Activity;

/**
 * Created by Sasinun on 5/28/16.
 */
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;

import com.google.gson.Gson;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import model.Photo;
import model.PhotoList;
import my500pic.ConstantUtils;
import my500pic.CustomJSONObjectRequest;
import my500pic.MyApplication;
import my500pic.MySingleton;
import test.em.com.mycollections.R;

public class SplashActivity extends BaseActivity implements Response.Listener,
        Response.ErrorListener {


    private CustomJSONObjectRequest jsonRequest;
    private Gson gson;
    private String REQUEST_TAG = "myRequestTag";
    private RequestQueue mQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_splash);

        startProgressDialog();

        gson = new Gson();

//        mQueue = CustomVolleyRequestQueue.getInstance(this.getApplicationContext())
//                .getRequestQueue();
        jsonRequest = new CustomJSONObjectRequest(Request.Method.GET, ConstantUtils.TEST_URL,
                new JSONObject(), this, this);
//        jsonRequest.setTag(REQUEST_TAG);
//        mQueue.add(jsonRequest);

        MySingleton.getInstance(this.getApplicationContext()).addToRequestQueue(jsonRequest, REQUEST_TAG);
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    public void onErrorResponse(VolleyError error) {
        stopProgressDialog();
        Toast.makeText(this,"Network error, \nPlease try again later",Toast.LENGTH_LONG).show();
    }

    @Override
    public void onResponse(Object response) {


        JSONObject jsonObj = (JSONObject) response;
        PhotoList phoObj = gson.fromJson(String.valueOf(jsonObj), PhotoList.class);
        MyApplication.photoListGlobal = phoObj;
        MyApplication.mapGlobal = getCategory(phoObj);
        sortPositionMap();
        getPhotoList();
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
        finish();
        stopProgressDialog();

    }

    private HashMap<Integer, String> getCategory(PhotoList photos){

        HashMap<Integer, String> map = new HashMap<Integer, String>();
        int category = 0;
        Photo photo;

        for(int i=0;i<photos.getPhotos().size();i++){
            photo = photos.getPhotos().get(i);
            category = photo.getCategory();
            map.put(category,ConstantUtils.CATEGORY_ARRAY[category]);
        }
        return map;
    };

    private HashMap<Integer,Integer> sortPositionMap(){
        HashMap<Integer,String> map = MyApplication.mapGlobal;
        HashMap<Integer,Integer> mapPos = new HashMap<>();
        int keyCategory;
        int position = 0;
        for ( int key : map.keySet() ) {
           keyCategory = key;
            mapPos.put(keyCategory,position);
            position++;
        }
        MyApplication.photoPosGlobal = mapPos;
        return mapPos;
    }
    private HashMap<Integer,ArrayList<Photo>> getPhotoList(){
        HashMap<Integer,ArrayList<Photo>> photoList = new HashMap<>();
        HashMap<Integer,Integer> mapPos = MyApplication.photoPosGlobal;
        int size = MyApplication.photoPosGlobal.size();
        int position =0 ;
        int category;
        for ( int key : mapPos.keySet() ) {
            category = key;
            photoList.put(position,ConstantUtils.getPhotoListByCategory(MyApplication.photoListGlobal,category));
            position++;
        }
        TreeMap<Integer, ArrayList<Photo>> map = new TreeMap<Integer,ArrayList<Photo>>(photoList);
        MyApplication.photoLisTreeMapGlobalt = map;

        return photoList;
    }

}

package test.em.com.mycollections.Activity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import java.util.HashMap;

import my500pic.MyApplication;
import test.em.com.mycollections.R;

public class CategoryActivity extends BaseActivity {

    private HashMap<Integer,String> map;
    private TextView txt;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        txt = (TextView) findViewById(R.id.textView3);
        listView = (ListView) findViewById(R.id.listView);

        map = MyApplication.mapGlobal;

        txt.setText(map.toString());
    }
}

package test.em.com.mycollections;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;

import model.Photo;
import model.PhotoList;
import my500pic.MySingleton;


public class CollectionListAdapter extends RecyclerView.Adapter<CollectionListAdapter.MyViewHolder>{
    private TreeMap<Integer,ArrayList<Photo>> dataList;
    private ArrayList<Photo> list;
    private Context context;
    ImageLoader mImageLoader;
    private int listSize=0;
    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView title;
        public TextView author;
        public ImageView image;
        public MyViewHolder(View view) {
            super(view);
            image = (ImageView) view.findViewById(R.id.iconId);
            title = (TextView) view.findViewById(R.id.title_name);
            author = (TextView) view.findViewById(R.id.author);
        }
    }

    public CollectionListAdapter(Context context, TreeMap<Integer, ArrayList<Photo>> dataList) {
        this.dataList = dataList;
        this.context = context;

        mImageLoader = MySingleton.getInstance(context).getImageLoader();
    }
    public CollectionListAdapter(Context context, TreeMap<Integer, ArrayList<Photo>> dataList,int position) {
        this.dataList = dataList;
        this.context = context;
        ArrayList<Photo> photoArray = dataList.get(position);
        listSize = photoArray.size();
        list = photoArray;
        mImageLoader = MySingleton.getInstance(context).getImageLoader();
    }
    public CollectionListAdapter(Context context,ArrayList<Photo> list) {
        this.list = list;
        this.context = context;
        mImageLoader = MySingleton.getInstance(context).getImageLoader();
    }

    @Override
    public int getItemCount() {
        return listSize;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.collection_list, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

//        ArrayList<Photo> data = dataList.get(position);
//        holder.title.setText(data.get(position).getName());
//        String imageUrl = data.get(position).getImageUrl();
//        //holder.author.setText(data.get(position).get);
//        mImageLoader.get(imageUrl, ImageLoader.getImageListener(holder.image,
//        R.drawable.ic_launcher, R.drawable.ic_launcher));
//        holder.author.setText(data.get(position).getUser().getFullname());

        Photo data = list.get(position);
        holder.title.setText("Title : "+data.getName());
        String imageUrl = data.getImageUrl();
        //holder.author.setText(data.get(position).get);
        mImageLoader.get(imageUrl, ImageLoader.getImageListener(holder.image,
                R.drawable.ic_launcher, R.drawable.ic_launcher));
        holder.author.setText("Author : "+ data.getUser().getFullname());
    }
}

//ImageLoader mImageLoader;
//ImageView mImageView;
//The URL for the image that is being loaded.
//private static final String IMAGE_URL =
//        "http://developer.android.com/images/training/system-ui.png";
//        ...
//        mImageView = (ImageView) findViewById(R.id.regularImageView);
//
//// Get the ImageLoader through your singleton class.
//        mImageLoader = MySingleton.getInstance(this).getImageLoader();
//        mImageLoader.get(IMAGE_URL, ImageLoader.getImageListener(mImageView,
//        R.drawable.def_image, R.drawable.err_image));


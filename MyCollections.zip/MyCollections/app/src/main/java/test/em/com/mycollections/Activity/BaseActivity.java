package test.em.com.mycollections.Activity;

/**
 * Created by Sasinun on 5/28/16.
 */
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import test.em.com.mycollections.R;

public class BaseActivity extends AppCompatActivity {
    private Context context;
    private ProgressDialog dialog_;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_base);
        context = this;
    }

    public void startProgressDialog(){
        try{
            if(!((BaseActivity)context).isFinishing()){
                if(dialog_ == null){
                    dialog_ = new ProgressDialog(this);
                }
                dialog_.show();
                dialog_.setContentView(R.layout.progress_bar);
                dialog_.setCancelable(false);
                dialog_.setCanceledOnTouchOutside(false);
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    public void stopProgressDialog(){
        if(dialog_ != null){
            dialog_.dismiss();
            dialog_ = null;
        }
    }

    @Override
    protected void onDestroy() {
        if(dialog_ != null){
            dialog_.dismiss();
            dialog_ = null;
        }
        super.onDestroy();
    }

    public void showAlertDialog(String title, String message,String positive_msg,String negative_msg){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                this);
        alertDialogBuilder.setTitle(title);
        alertDialogBuilder
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton(positive_msg,new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        dialog.dismiss();
                    }
                });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

}

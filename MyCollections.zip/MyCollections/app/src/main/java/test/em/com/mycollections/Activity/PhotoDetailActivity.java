package test.em.com.mycollections.Activity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;

import my500pic.MySingleton;
import test.em.com.mycollections.R;

/**
 * Created by sasinun on 5/29/2016.
 */
public class PhotoDetailActivity extends Activity{
    ImageView image;
    TextView title;
    TextView author;
    String title_text;
    String name;
    String url;
    ImageLoader mImageLoader;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.photo_detail);

        Intent i = getIntent();
        mImageLoader = MySingleton.getInstance(getApplicationContext()).getImageLoader();
        if(i!= null){
             title_text = i.getStringExtra("TITLE");
             name = i.getStringExtra("AUTHOR");
             url = i.getStringExtra("URL");
        }
        image = (ImageView) findViewById(R.id.iconId);
        title = (TextView) findViewById(R.id.title);
        title.setText("Title : " + title_text);
        author = (TextView) findViewById(R.id.author);
        author.setText("Author : "+ name);
        mImageLoader.get(url, ImageLoader.getImageListener(image,
                R.drawable.ic_launcher, R.drawable.ic_launcher));

    }
}

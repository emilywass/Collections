package my500pic;

/**
 * Created by Sasinun on 5/28/16.
 */
import android.app.Application;
import android.support.annotation.IntegerRes;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

import model.Photo;
import model.PhotoList;

public class MyApplication extends Application {

    public static String token = null;
    public static String tokenSecret = null;
    public static PhotoList photoListGlobal = null;
    public static HashMap<Integer,String> mapGlobal = null;
    public static HashMap<Integer,Integer> photoPosGlobal = null;
    public static HashMap<Integer,ArrayList<Photo>>  photoLisMapGlobalt= null;
    public static TreeMap<Integer,ArrayList<Photo>> photoLisTreeMapGlobalt= null;

}

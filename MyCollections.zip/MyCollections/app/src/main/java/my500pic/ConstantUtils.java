package my500pic;

/**
 * Created by Sasinun on 5/28/16.
 */
import java.util.ArrayList;

import model.Photo;
import model.PhotoList;

public class ConstantUtils {

    public static String BASE_URL = "https://api.500px.com/v1/photos?";
    public static String CONSUMER_KEY = "vHqdROAkTf3DCfI8daZYkOUWyccC3A3slB14wu4n";


    public static String TEST_URL = "https://api.500px.com/v1/photos?consumer_key=vHqdROAkTf3DCfI8daZYkOUWyccC3A3slB14wu4n";

    public static String[] CATEGORY_ARRAY = {"Uncategorized", "Celebrities", "Film",
            "Journalism", "Nude", "Black and White", "Still Life", "People", "Landscapes", "City and Architecture", "Abstract",
            "Animals", "Macro", "Travel", "Fashion", "Commercial", "Concert", "Sport", "Nature", "Performing Arts", "Family", "Street", "Underwater",
            "Food", "Fine Art", "Wedding", "Transportation", "Urban Exploration"};


    public static ArrayList<Photo> getPhotoListByCategory(PhotoList photos, int category) {
        ArrayList<Photo> list = new ArrayList<Photo>();
        int temp = 0;
        for (int i = 0; i < photos.getPhotos().size(); i++) {
            temp = photos.getPhotos().get(i).getCategory();
            if (temp == category) {
                list.add(photos.getPhotos().get(i));
            }
        }

        return list;
    }

}
